package com.akshay.unieat;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UnieatApplication {

	public static void main(String[] args) {
		SpringApplication.run(UnieatApplication.class, args);
	}

}
