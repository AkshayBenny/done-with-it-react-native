package com.akshay.unieat;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UnieatApplicationTests {

	@Test
	void contextLoads() {
	}

}
